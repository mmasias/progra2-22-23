package classGroup;



import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Inventory implements  Inventory2{
	 int capacity = 0;
	    ArrayList<Pets> items;

	    /**
	     * @param capacity  The number of items that the inventory can handle
	     */
	    public Inventory() {
			capacity = 10;
			this.items = new ArrayList<Pets>();
		}
	    public Inventory(int capacity) {
	        this.capacity = capacity;
	        this.items = new ArrayList<Pets>();
	    }
	    

	    


		/**
	     * AddItem method lets you add a new item to the inventory
	     *
	     * @param val       The String value that you want to add to inventory
	     * @exception FullStorageException  If the number of items has reached the capacity of the inventory
	     */
	    @Override
	    public void addItem(Pets val) throws FullStorageException {
	    	
	            if(hasAvailableStorage()){
	                this.items.add(val);
	            }
	            else {
	                throw new FullStorageException("No space left");
	            }
	    }

	    /**
	     * getItems method gives you the actual items in the inventory
	     *
	     * @return          Returns an ArrayList of the actual state of the inventory
	     */
	    @Override
	    public ArrayList<Pets> getItems() {
	        return this.items;
	    }

	    private Boolean hasAvailableStorage(){
	        return this.items.size() < this.capacity ? true: false;
	    }
	    public Boolean isFull(){
	        return this.hasAvailableStorage();
	    }
	    public boolean isEmpty() {
	    	boolean empty = false;
	    	if(items.size() == 0) {
	    		empty = true;
	    	}else {
	    		empty = false;
	    	}
	    	return empty; 
	    }
	    public int getItemsSize() {
	    	return items.size();
	    }
	    public Pets getItem(int n) {
	    	return items.get(n);
	    }
	    public void loadItems() {
	    	boolean endPets = false;
	    	Pets P1 = new Pets();
	    	int i = 0;
	    	
	    	
	    	Pets arrayPets[] = new Pets[5];
	    	for(int j = 0; j< arrayPets.length;j++) {
	    		arrayPets[j] = new Pets();
	    	}
	    	
	    	arrayPets[0].setId("AA");
	    	arrayPets[0].setSpecie("GATO");
	    	arrayPets[0].setRace("Siames");
	    	arrayPets[0].setAge(7);
	    	arrayPets[1].setId("AB");
	    	arrayPets[1].setSpecie("GATO");
	    	arrayPets[1].setRace("Corsair");
	    	arrayPets[1].setAge(3);
	    	arrayPets[2].setId("AC");
	    	arrayPets[2].setSpecie("GATO");
	    	arrayPets[2].setRace("Egipcio");
	    	arrayPets[2].setAge(2);
	    	arrayPets[3].setId("AD");
	    	arrayPets[3].setSpecie("GATO");
	    	arrayPets[3].setRace("Geforce");
	    	arrayPets[3].setAge(8);
	    	arrayPets[4].setId("AE");
	    	arrayPets[4].setSpecie("GATO");
	    	arrayPets[4].setRace("Fiux");
	    	arrayPets[4].setAge(4);
	    	do {
	    	try {	
	    	addItem(arrayPets[i]);
	    	if(i<arrayPets.length-1) {
	    		i++;
	    	}else {
	    		endPets = true;
	    	}
	    	
	    	}catch(FullStorageException e) {
	    		endPets=true;
	    	}
	    	}while(endPets == false);
	    	
	    	
	    	
	    }
	    public int getCapacity() {
			return capacity;
		}

		public void setCapacity(int capacity) {
			this.capacity = capacity;
		}

		public int inventorySize() {
	    	
	    	return items.size();
	    }
		
		public void listItems() {
			
			for (Object i : items) {
	   			 
                // Printing the elements of ArrayList
                System.out.println(i);
        }
	}
		public void loadItemsFromFile() {
			File archivo = null;
		      FileReader fr = null;
		      BufferedReader br = null;
		      int contador = 0;
		      
		      try {
		         // Apertura del fichero y creacion de BufferedReader para poder
		         // hacer una lectura comoda (disponer del metodo readLine()).
		         archivo = new File ("C:\\Users\\Casti\\eclipse-workspace\\EX004Exceptions\\src\\data\\infoPet.dat");
		         fr = new FileReader (archivo);
		         br = new BufferedReader(fr);

		         // Lectura del fichero
		         String linea;
		         String[] arrSplit;
		         Pets P1;
		         while(((linea=br.readLine())!=null)) {
		        	 arrSplit = linea.split(","); 
		        	 
		        	 //System.out.println(linea);
		        	 P1 = new Pets();
		        	 P1.setId(arrSplit[0]);
		        	 P1.setSpecie(arrSplit[1]);
		        	 P1.setRace(arrSplit[2]);
		        	 P1.setAge(Integer.parseInt(arrSplit[3]));
		        	 
		        	 addItem(P1);
		        	 
		         }
		           
		      }
		      catch(FullStorageException e){
			        
			      }
		      catch(Exception e){
		         e.printStackTrace();
		      }finally{
		         // En el finally cerramos el fichero, para asegurarnos
		         // que se cierra tanto si todo va bien como si salta 
		         // una excepcion.
		         try{                    
		            if( null != fr ){   
		               fr.close();     
		            }                  
		         }catch (Exception e2){ 
		            e2.printStackTrace();
		         }
		      }
		}
		
    
    
}