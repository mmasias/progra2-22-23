package classGroup;

import java.util.ArrayList;

public interface Inventory2 {
	
    public abstract void addItem(Pets val) throws FullStorageException;
    public abstract ArrayList<Pets> getItems();
   
}