package classGroup;



import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args)   {

    	Inventory I1 = new Inventory(10);
        Scanner input = new Scanner(System.in);
        Pets newObject = new Pets();
        boolean end = false;
        int capacity;
        int option = 0;
        boolean capacityCorrect = false;
        boolean endMenu = false;
        

        do {
        System.out.println("Ingresa la capacidad de tu inventario: ");
        try {
        capacity = Integer.parseInt(input.nextLine()); //nextInt has problems with EOL
        I1.setCapacity(capacity);
        capacityCorrect = true;
        }catch (NumberFormatException e) {
        	System.out.println("Error, debe introducir un valor numerico");
        }	
        }while(capacityCorrect == false);
        System.out.println("Capacidad:" + I1.capacity);
        
        //Inventory inv = new Inventory(capacity);
        do{
        	
        	do {
        
        		try {
        
        			System.out.println("Seleccione una opcion: ");
        			System.out.println("Opcion 1: Cargar objeto en el inventario");
        			System.out.println( "Opcion 2: Mostrar inventario");
        			System.out.println("Opcion 3: Cargar inventario");
        			System.out.println( "Opcion 4: Finalizar");
        			option = Integer.parseInt(input.nextLine());
        			endMenu = true;
        		}catch(NumberFormatException e) {
        			System.out.println("Error, debe introducir valores numericos");
        		}
        	
        	}while(endMenu == false);
        	
       switch (option) { 
       case 1:
    	   try {
    	   if(I1.isFull()){
    		   
    	   I1.loadItems();
    	   }else{   
    		   throw new FullStorageException("No space left");
    	   }
    	   }catch(FullStorageException e) {
    		   
    	   }
        break;
       case 2:
    	   System.out.println("Listado de mascotas: ");
       		
       		I1.listItems();
       	
       	
        // secuencia de sentencias.
        break; 
       case 3:
    	   
    	   I1.loadItemsFromFile();
        // secuencia de sentencias.
        break;
       case 4:
       	System.out.println("Finalizo el programa.");
       	end = true;
       	break;
       default:
    	   System.out.println("Error, opciones validas del 1 al 4.");
        // Default secuencia de sentencias.
     }
       
        
        
        }while (end == false);
        
        
    }
}

        //TODO Borrar Elementos del inventario, Añadir Elementos a través de un archivo externo y manejar excepciones
        // como FileNotFoundException, también crear validaciones por medio de Excepciones personalizadas

        
    



      
        

        //TODO Borrar Elementos del inventario, Añadir Elementos a través de un archivo externo y manejar excepciones
        // como FileNotFoundException, también crear validaciones por medio de Excepciones personalizadas

