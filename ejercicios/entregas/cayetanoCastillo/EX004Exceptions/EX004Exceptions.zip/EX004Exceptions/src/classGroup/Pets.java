package classGroup;

public class Pets {
	private String id;
	private String specie;
	private String race;
	private int age;
	
	public Pets() {
		super();
		id = "Unknown";
		specie = "Unknown";
		race = "Unknown";
		age = 0;
	}
	
	public Pets(String id, String specie, String race, int age) {
		super();
		this.id = id;
		this.specie = specie;
		this.race = race;
		this.age = age;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSpecie() {
		return specie;
	}
	public void setSpecie(String specie) {
		this.specie = specie;
	}
	public String getRace() {
		return race;
	}
	public void setRace(String race) {
		this.race = race;
	}
	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Pets [id=" + id + ", specie=" + specie + ", race=" + race + ", age=" + age + "]";
	}

	
	
	
	
	
}
