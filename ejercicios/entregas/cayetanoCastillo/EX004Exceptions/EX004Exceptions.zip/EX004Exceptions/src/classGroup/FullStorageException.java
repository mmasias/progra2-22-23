package classGroup;

public class FullStorageException extends Exception{
	  public FullStorageException(String message) {
	        super(message);
	        System.out.println(message);
	    }
}