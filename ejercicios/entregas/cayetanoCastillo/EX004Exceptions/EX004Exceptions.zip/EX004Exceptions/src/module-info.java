/**
 * 
 */
/**
 * @author Casti
 *
 */
module EX004Exceptions {
}