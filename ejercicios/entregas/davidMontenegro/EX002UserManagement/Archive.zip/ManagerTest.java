package  EX002UserManagement;
import org.junit.Test;
class ManagerTest {
    @test
    void logIng(){

    }
    void authentification(){

    }
}