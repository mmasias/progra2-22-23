package main;

public class MenuOption {
    private String description;

    public MenuOption(String description){
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
}

