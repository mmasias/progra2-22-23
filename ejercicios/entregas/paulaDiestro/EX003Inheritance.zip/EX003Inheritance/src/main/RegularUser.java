package main;

public class RegularUser {
}
