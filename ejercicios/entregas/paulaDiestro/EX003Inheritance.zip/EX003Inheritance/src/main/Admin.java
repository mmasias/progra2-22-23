package main;

public class Admin {
    private boolean isAdmin;
    private boolean isAdmin() {
        return false;
    }

    public void setAdmin(boolean admin) {
        isAdmin = admin;
    }
}
