package main;

import java.util.List;

public class Option {
    private String[] options;
    private int maxOptions;
    private int selectedOption;

    public Option(int selectedOption, int maxOptions){
        selectedOption = 0;
        maxOptions = 4;
    }
    public void addOption(String option){

    }
    public String getOption(int index){
        return null;
    }

    public void selectOption(int index) {

    }
    public int getSelectedOption() {
        return selectedOption;
    }
}
