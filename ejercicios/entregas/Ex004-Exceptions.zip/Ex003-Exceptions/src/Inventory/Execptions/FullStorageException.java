package Inventory.Execptions;

public class FullStorageException extends Exception{
    public FullStorageException(String message) {
        super(message);
    }
}
